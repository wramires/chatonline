<?php

return array (
  'dbHost' => 'localhost',
  'dbPort' => '3306',
  'dbUser' => 'pointn18_bdlive',
  'dbPassword' => 'Kamijo563',
  'dbName' => 'pointn18_bdlive2',
  'superUser' => 'admin',
  'superPass' => 'Kamijo563',
  'services' => 
  array (
    'mailer' => 
    array (
      'smtp' => '',
      'smtpSecure' => 'ssl',
      'smtpHost' => '',
      'smtpPort' => '465',
      'smtpUser' => '',
      'smtpPass' => '',
    ),
  ),
  'appSettings' => 
  array (
    'contactMail' => 'stremon@msn.com',
  ),
);

?>