// +------------------------------------------------ -----------------------
// | Program Name: Welcome to the source forum to learn and share with each other
// +------------------------------------------------ -----------------------
// | Copyright: (c) 2008-2018 https://yuanmaye.com rights reserved.
// +------------------------------------------------ -----------------------
// | Developer: Source forum
// +------------------------------------------------ -----------------------
// | Author: Source Forum QQ Group: 385343446
// +------------------------------------------------ -----------------------


?* Thanks for the support! Your support is our greatest motivation! Download all resources of this site for free forever!

?* The source code you downloaded from the source forum yuanmaye.com

?* Welcome to visit the latest resources to get the latest updates! More free commercial source code is not to be missed! !

?* Permanent domain name: https://yuanmaye.com/


############################################################################# ##################################################

����������������������������������������������������������������
Disclaimer:
???According to Article 17 of the Second Revision of the Computer Software Protection Regulations of January 30, 2013:
??In order to learn and study the design ideas and principles contained in the software, software can be installed, displayed, transmitted or stored in software, without the permission of the software copyright owner, and will not be paid for it!
??
??In view of this, I also hope that everyone can follow this description to study software!
??
??All the source code of this site comes from the network collection modification or exchange! If you infringe on your rights, please let us know and we will deal with it immediately!