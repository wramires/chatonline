Drop Table If Exists `%db_name%`.mirrormx_customer_chat_user_department;
Drop Table If Exists `%db_name%`.mirrormx_customer_chat_shared_file;
Drop Table If Exists `%db_name%`.mirrormx_customer_chat_upload;
Drop Table If Exists `%db_name%`.mirrormx_customer_chat_message;
Drop Table If Exists `%db_name%`.mirrormx_customer_chat_talk;
Drop Table If Exists `%db_name%`.mirrormx_customer_chat_department;
Drop Table If Exists `%db_name%`.mirrormx_customer_chat_user;
Drop Table If Exists `%db_name%`.mirrormx_customer_chat_data;
